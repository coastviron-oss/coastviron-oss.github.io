// CK 구글챗 사진 창 (docs/chat-image-popup.md). 구글챗에서 사진을 누르면 구글챗 화면 전체를 덮는 보기 대신,
// 카톡처럼 따로 창에 원본 크기로 연다. 대화 글은 읽지 않는다. 누른 사진의 주소와 창 크기만 이 확장의 배경 작업
// (background.js)에 넘기고, 밖으로는 아무것도 보내지 않는다.
// Ctrl·Shift·Alt·Cmd를 누른 채 누르거나 키보드(Enter)로 열면 구글챗 원래 보기가 그대로 열린다(키보드·스크립트가 만든
// 누름은 detail이 0이라 건드리지 않는다).
(() => {
  const { originalUrl, aspect, viewerBounds, clickedImage } = globalThis.ckChatImage;

  function openHere(url, bounds) {
    window.open(url, "ck-chat-image", `popup,left=${bounds.left},top=${bounds.top},width=${bounds.width},height=${bounds.height}`);
  }

  // Capture on window runs before any handler of Chat's page, so Chat's full-screen viewer never sees this click.
  window.addEventListener(
    "click",
    (event) => {
      if (event.button !== 0 || event.ctrlKey || event.shiftKey || event.altKey || event.metaKey) return;
      if (event.detail === 0) return; // not a mouse, pen or touch press (keyboard, or dispatched by a script)
      if (!chrome.runtime?.id) return; // the extension was updated or turned off: leave Chat as it is
      const image = clickedImage(event.target);
      if (!image) return;
      const src = image.currentSrc || image.src;
      const url = originalUrl(src);
      const bounds = viewerBounds(aspect(src, image.naturalWidth, image.naturalHeight), window.screen, {
        screenX: window.screenX,
        screenY: window.screenY,
        outerWidth: window.outerWidth,
        outerHeight: window.outerHeight,
      });
      event.preventDefault();
      event.stopImmediatePropagation();
      // If the background cannot open the viewer, an ordinary popup still beats a click that does nothing.
      try {
        chrome.runtime.sendMessage({ type: "open-image", url, bounds }).then(
          (reply) => {
            if (!reply?.ok) openHere(url, bounds);
          },
          () => openHere(url, bounds),
        );
      } catch {
        openHere(url, bounds); // the extension went away between the check above and now
      }
    },
    true,
  );
})();
