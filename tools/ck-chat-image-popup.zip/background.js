// CK 구글챗 사진 창 (docs/chat-image-popup.md) — 사진 모아보기 창을 하나 열고, 다음 사진도 그 창에 띄운다(카톡처럼).
// 사람이 창을 닫으면 다음 사진 때 새로 연다. 사람이 바꾼 창 크기·위치는 기억해 다음에 새로 열 때 쓴다.
// 회사 검색 페이지의 사진 모아보기 주소가 아니면 열지 않는다.
const KEY = "viewer";
const SIZE_KEY = "viewerBounds";
const GALLERY = "https://coastviron-oss.github.io/search/#photos?";
let queue = Promise.resolve();

// Everything that reads or writes the remembered viewer runs one at a time, so a closing window and a new click
// never work from each other's stale view (two viewers, or forgetting the one on screen).
function serial(work) {
  queue = queue.catch(() => undefined).then(work);
  return queue;
}

function cleanBounds(bounds) {
  const out = {};
  for (const key of ["left", "top", "width", "height"]) {
    if (Number.isFinite(bounds?.[key])) out[key] = Math.round(bounds[key]);
  }
  return out;
}

/** The remembered window moved onto the screen Chat is on (used only when Chrome refuses the remembered place). */
function onScreen(remembered, screen) {
  if (Object.keys(remembered).length !== 4 || Object.keys(screen).length !== 4) return null;
  const width = Math.min(remembered.width, screen.width);
  const height = Math.min(remembered.height, screen.height);
  const clamp = (value, low, size) => Math.min(Math.max(value, low), low + size);
  return {
    left: clamp(remembered.left, screen.left, screen.width - width),
    top: clamp(remembered.top, screen.top, screen.height - height),
    width,
    height,
  };
}

async function show(url, bounds, screen) {
  const { [KEY]: saved } = await chrome.storage.session.get(KEY);
  // tabs.update without a tab id would move the person's own current tab, so only a known id is reused.
  if (Number.isInteger(saved?.tabId)) {
    let reused = true;
    try {
      // Same page, new #photos?… address: the page moves to the new picture without reloading.
      await chrome.tabs.update(saved.tabId, { url });
    } catch {
      reused = false; // the person closed the viewer (or Chrome did); open a new one below
    }
    if (reused) {
      // The window keeps the size and place the person gave it; it only comes forward.
      await chrome.windows.update(saved.windowId, { focused: true }).catch(() => undefined);
      return;
    }
  }
  const { [SIZE_KEY]: stored } = await chrome.storage.local.get(SIZE_KEY);
  const clean = stored ? cleanBounds(stored) : {};
  const remembered = Object.keys(clean).length === 4 ? clean : null;
  const open = (place) => chrome.windows.create({ url, type: "popup", focused: true, ...place });
  // Where the person left it, even on another monitor. Chrome (102+; the manifest asks for 120) refuses a place less
  // than half on the screens it has (a monitor since unplugged); then the same size goes onto the screen Chat is on.
  const created = remembered
    ? await open(remembered).catch(() => open(onScreen(remembered, screen) ?? bounds))
    : await open(bounds);
  await chrome.storage.session.set({ [KEY]: { windowId: created.id, tabId: created.tabs?.[0]?.id } });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== "open-photos" || sender.id !== chrome.runtime.id) return false;
  if (typeof message.url !== "string" || !message.url.startsWith(GALLERY) || message.url.length > 8192) {
    sendResponse({ ok: false });
    return false;
  }
  // One at a time, so two quick clicks never open two viewers.
  serial(() => show(message.url, cleanBounds(message.bounds), cleanBounds(message.screen))).then(
    () => sendResponse({ ok: true }),
    () => sendResponse({ ok: false }),
  );
  return true;
});

// Remember the size and place the person gives the viewer (KakaoTalk keeps its viewer where it was left).
// Chrome ignores a listener's promise, so a failure is caught here rather than left unhandled.
chrome.windows.onBoundsChanged.addListener((win) =>
  serial(async () => {
    const { [KEY]: saved } = await chrome.storage.session.get(KEY);
    if (saved?.windowId !== win.id) return;
    const bounds = cleanBounds(win);
    if (Object.keys(bounds).length === 4 && bounds.width >= 300 && bounds.height >= 200) {
      await chrome.storage.local.set({ [SIZE_KEY]: bounds });
    }
  }).catch(() => undefined),
);

chrome.windows.onRemoved.addListener((windowId) =>
  serial(async () => {
    const { [KEY]: saved } = await chrome.storage.session.get(KEY);
    if (saved?.windowId === windowId) await chrome.storage.session.remove(KEY);
  }).catch(() => undefined),
);
