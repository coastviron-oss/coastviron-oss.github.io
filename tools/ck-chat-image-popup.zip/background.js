// CK 구글챗 사진 창 (docs/chat-image-popup.md) — 사진 보기 창을 하나 열고, 다음 사진도 그 창에 띄운다(카톡처럼).
// 사람이 창을 닫으면 다음 사진 때 새로 연다. 구글챗 사진 주소가 아니면 열지 않는다.
const KEY = "viewer";
const CHAT_IMAGE = /^https:\/\/chat\.google\.com\/api\/get_attachment_url\?/;
let queue = Promise.resolve();

function cleanBounds(bounds) {
  const out = {};
  for (const key of ["left", "top", "width", "height"]) {
    if (Number.isFinite(bounds?.[key])) out[key] = Math.round(bounds[key]);
  }
  return out;
}

async function show(url, bounds) {
  const { [KEY]: saved } = await chrome.storage.session.get(KEY);
  // tabs.update without a tab id would move the person's own current tab, so only a known id is reused.
  if (Number.isInteger(saved?.tabId)) {
    let reused = true;
    try {
      await chrome.tabs.update(saved.tabId, { url });
    } catch {
      reused = false; // the person closed the viewer (or Chrome did); open a new one below
    }
    if (reused) {
      // The picture is already showing; a refused size must not open a second window, but the viewer still comes forward.
      await chrome.windows
        .update(saved.windowId, { ...bounds, focused: true })
        .catch(() => chrome.windows.update(saved.windowId, { focused: true }).catch(() => undefined));
      return;
    }
  }
  const created = await chrome.windows.create({ url, type: "popup", focused: true, ...bounds });
  await chrome.storage.session.set({ [KEY]: { windowId: created.id, tabId: created.tabs?.[0]?.id } });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== "open-image" || sender.id !== chrome.runtime.id) return false;
  if (typeof message.url !== "string" || !CHAT_IMAGE.test(message.url)) {
    sendResponse({ ok: false });
    return false;
  }
  // One at a time, so two quick clicks never open two viewers.
  queue = queue
    .catch(() => undefined)
    .then(() => show(message.url, cleanBounds(message.bounds)))
    .then(
      () => sendResponse({ ok: true }),
      () => sendResponse({ ok: false }),
    );
  return true;
});

chrome.windows.onRemoved.addListener(async (windowId) => {
  const { [KEY]: saved } = await chrome.storage.session.get(KEY);
  if (saved?.windowId === windowId) await chrome.storage.session.remove(KEY);
});
