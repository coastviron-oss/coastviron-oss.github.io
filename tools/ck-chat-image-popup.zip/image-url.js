// CK 구글챗 사진 창 (docs/chat-image-popup.md) — 구글챗 사진 주소, 사진 모아보기 주소, 보기 창 크기를 다루는 순수 함수.
// content.js보다 먼저 실리고, 시험(lib/chat-image-popup.test.ts)도 이 파일을 그대로 쓴다.
// 사진 모아보기 화면은 회사 검색 페이지(https://coastviron-oss.github.io/search/)의 `#photos?` 주소다(web/photos.ts).
// 확장은 어느 방·어느 글·몇 번째 사진인지만 넘기고, 화면은 그 페이지가 그린다. 그래서 화면을 고쳐도 확장은 다시 깔 필요가 없다.
// 구글챗 화면의 사진은 `https://chat.google.com/api/get_attachment_url?url_type=FIFE_URL&content_type=image/png&...&sz=w512`
// 모양이다(2026-10-11 실제 화면에서 확인). `sz`가 크기다: w512는 너비 512, s330-c는 330 정사각형으로 자른 것, s0은 원본.
globalThis.ckChatImage = (() => {
  const HOST = "chat.google.com";
  const PATH = "/api/get_attachment_url";
  const GALLERY = "https://coastviron-oss.github.io/search/#photos?";
  const ID = /^[A-Za-z0-9_-]{1,64}$/;

  /** The original-size address of a Chat image attachment; null for anything else (profile photos, emoji, videos, files). */
  function originalUrl(src) {
    let url;
    try {
      url = new URL(src);
    } catch {
      return null;
    }
    // The same rule as the gallery page (lib/photo-gallery.ts chatPicture), so every picture opened here also shows there.
    if (url.protocol !== "https:" || url.host !== HOST || url.username || url.password || url.pathname !== PATH) return null;
    if (url.searchParams.get("url_type") !== "FIFE_URL") return null;
    if (!(url.searchParams.get("content_type") ?? "").startsWith("image/")) return null;
    if (!url.searchParams.get("attachment_token")) return null;
    url.searchParams.set("sz", "s0");
    return url.href;
  }

  /**
   * The viewer window on first open: up to 960 wide and 90% of the screen tall, centred on the Chat window and kept on
   * that screen. `screen` is window.screen (availLeft/Top/Width/Height); `around` is the Chat window (screenX/Y,
   * outerWidth/Height). After that the window keeps whatever size the person gives it (background.js remembers it).
   */
  function viewerBounds(screen, around) {
    const width = Math.min(960, Math.floor(screen.availWidth * 0.9));
    const height = Math.floor(screen.availHeight * 0.9);
    const clamp = (value, low, high) => Math.min(Math.max(value, low), Math.max(low, high));
    const availLeft = screen.availLeft ?? 0;
    const availTop = screen.availTop ?? 0;
    return {
      left: clamp(Math.round(around.screenX + (around.outerWidth - width) / 2), availLeft, availLeft + screen.availWidth - width),
      top: clamp(Math.round(around.screenY + (around.outerHeight - height) / 2), availTop, availTop + screen.availHeight - height),
      width,
      height,
    };
  }

  /**
   * Which picture of which room was clicked, read from Chat's own markers around it, checked 2026-10-11 on the real
   * page: the room `[data-group-id="space/<id>"]` (= API `spaces/<id>`), the message `[data-id]` (= the part after the
   * dot of the API message name), and the tile `[data-chip-index]` (= position in the API attachment list). Direct
   * messages show `dm/<id>`; they are not copied into the company memory, so the gallery shows only the clicked picture
   * there (whether `<id>` equals the API space id was not checked). Each part is null when Chat did not mark it.
   */
  function photoTarget(image) {
    const attr = (selector, name) => image.closest(selector)?.getAttribute(name) ?? "";
    const space = /^(?:space|dm)\/([A-Za-z0-9_-]{1,64})$/.exec(attr("[data-group-id]", "data-group-id"))?.[1] ?? null;
    const message = attr("[data-id]", "data-id");
    const index = attr("[data-chip-index]", "data-chip-index");
    return {
      space,
      message: ID.test(message) ? message : null,
      index: /^\d{1,3}$/.test(index) ? Number(index) : null,
    };
  }

  /** The 사진 모아보기 address for a clicked picture. `stamp` makes every click a new address, so the open window moves. */
  function galleryUrl(src, target, stamp) {
    const params = new URLSearchParams();
    if (target.space) params.set("space", target.space);
    if (target.message) params.set("msg", target.message);
    if (target.index !== null) params.set("i", String(target.index));
    params.set("src", src);
    params.set("t", String(stamp));
    return GALLERY + params.toString();
  }

  /**
   * The Chat picture a click landed on, or null. In Chat a picture is `img` inside its own `[role=button]`; that button
   * must hold exactly this one attachment image and no words other than a "+3" more-pictures label (the gallery shows
   * them all). Anything inside Chat's own viewer (`[role=dialog]`) is left alone.
   */
  function clickedImage(target) {
    if (!target || typeof target.closest !== "function") return null;
    if (target.closest('[role="dialog"]')) return null;
    const button = target.closest('[role="button"]');
    if (!button) return null;
    const images = button.querySelectorAll("img");
    if (images.length !== 1) return null;
    const words = (button.textContent ?? "").trim();
    if (words !== "" && !/^\+\s?\d{1,3}$/.test(words)) return null;
    const image = images[0];
    return originalUrl(image.currentSrc || image.src) ? image : null;
  }

  return Object.freeze({ originalUrl, viewerBounds, photoTarget, galleryUrl, clickedImage });
})();
