// CK 구글챗 사진 창 (docs/chat-image-popup.md) — 구글챗 사진 주소, 사진 모아보기 주소, 보기 창 크기를 다루는 순수 함수.
// content.js보다 먼저 실리고, 시험(lib/chat-image-popup.test.ts)도 이 파일을 그대로 쓴다.
// 사진 모아보기 화면은 회사 검색 페이지(http://100.83.231.50:8791/)의 `#photos?` 주소다(web/photos.ts).
// 확장은 어느 방·어느 글·몇 번째 사진인지만 넘기고, 화면은 그 페이지가 그린다. 그래서 화면을 고쳐도 확장은 다시 깔 필요가 없다.
// 구글챗 화면의 사진은 2026-11부터 `https://lh3.googleusercontent.com/chat_attachment/<토큰>=s330-c-rw` 모양이다
// (2026-11-26 실제 화면에서 확인, 토큰 327자. 그 전에는 `https://chat.google.com/api/get_attachment_url?...&sz=w512`).
// `=` 뒤가 크기다: w512는 너비 512, s330-c는 330 정사각형으로 자른 것, s0은 원본. 옛 모양도 계속 받는다.
globalThis.ckChatImage = (() => {
  const HOST = "chat.google.com";
  // 크롬에 구글 계정이 여럿이면 두 번째부터는 `/u/<번호>/api/get_attachment_url`(직원 자리 2026-11-04).
  const PATH = /^(\/u\/\d{1,2})?\/api\/get_attachment_url$/;
  const GALLERY = "http://100.83.231.50:8791/#photos?";
  const ID = /^[A-Za-z0-9_-]{1,64}$/;
  const FIFE_HOST = "lh3.googleusercontent.com";
  const FIFE_PATH = /^\/chat_attachment\/([A-Za-z0-9_-]{20,2048})(?:=[A-Za-z0-9-]{1,40})?$/;

  /** The original-size address of a Chat image attachment; null for anything else (profile photos, emoji, videos, files). */
  function originalUrl(src) {
    let url;
    try {
      url = new URL(src);
    } catch {
      return null;
    }
    // The same rule as the gallery page (lib/photo-gallery.ts chatPicture), so every picture opened here also shows there.
    if (url.protocol === "https:" && url.host === FIFE_HOST && !url.username && !url.password && url.search === "") {
      const token = FIFE_PATH.exec(url.pathname)?.[1];
      return token ? `https://${FIFE_HOST}/chat_attachment/${token}=s0` : null;
    }
    if (url.protocol !== "https:" || url.host !== HOST || url.username || url.password || !PATH.test(url.pathname)) return null;
    if (url.searchParams.get("url_type") !== "FIFE_URL") return null;
    if (!(url.searchParams.get("content_type") ?? "").startsWith("image/")) return null;
    if (!url.searchParams.get("attachment_token")) return null;
    url.searchParams.set("sz", "s0");
    return url.href;
  }

  /**
   * The viewer window on first open: up to 960 wide and 90% of the screen tall, centred on the Chat window and kept on
   * that screen. `screen` is window.screen (availLeft/Top/Width/Height); `around` is the Chat window (screenX/Y,
   * outerWidth/Height). After that the window keeps whatever size the person gives it (background.js remembers it).
   */
  function viewerBounds(screen, around) {
    const width = Math.min(960, Math.floor(screen.availWidth * 0.9));
    const height = Math.floor(screen.availHeight * 0.9);
    const clamp = (value, low, high) => Math.min(Math.max(value, low), Math.max(low, high));
    const availLeft = screen.availLeft ?? 0;
    const availTop = screen.availTop ?? 0;
    return {
      left: clamp(Math.round(around.screenX + (around.outerWidth - width) / 2), availLeft, availLeft + screen.availWidth - width),
      top: clamp(Math.round(around.screenY + (around.outerHeight - height) / 2), availTop, availTop + screen.availHeight - height),
      width,
      height,
    };
  }

  /**
   * Which picture of which room was clicked, read from Chat's own markers around it, checked 2026-10-11 on the real
   * page: the room `[data-group-id="space/<id>"]` (= API `spaces/<id>`), the message `[data-id]` (= the part after the
   * dot of the API message name), and the tile `[data-chip-index]` (= position in the API attachment list). Direct
   * messages show `dm/<id>`; they are not copied into the company memory, so the gallery shows only the clicked picture
   * there (whether `<id>` equals the API space id was not checked). Each part is null when Chat did not mark it.
   */
  function photoTarget(image) {
    const attr = (selector, name) => image.closest(selector)?.getAttribute(name) ?? "";
    const space = /^(?:space|dm)\/([A-Za-z0-9_-]{1,64})$/.exec(attr("[data-group-id]", "data-group-id"))?.[1] ?? null;
    const message = attr("[data-id]", "data-id");
    const index = attr("[data-chip-index]", "data-chip-index");
    return {
      space,
      message: ID.test(message) ? message : null,
      index: /^\d{1,3}$/.test(index) ? Number(index) : null,
    };
  }

  /** Chrome's n-th Google account from the Chat page path (`/u/<n>/…`), or null for the first. */
  function chatAccount(pathname) {
    return /^\/u\/(\d{1,2})(?:\/|$)/.exec(pathname ?? "")?.[1] ?? null;
  }

  /**
   * The 사진 모아보기 address for a clicked picture. `stamp` makes every click a new address, so the open window moves.
   * `account` (chatAccount) lets the page ask for the room's pictures through the same Google account.
   */
  function galleryUrl(src, target, stamp, account = null) {
    const params = new URLSearchParams();
    if (target.space) params.set("space", target.space);
    if (target.message) params.set("msg", target.message);
    if (target.index !== null) params.set("i", String(target.index));
    if (account !== null) params.set("u", account);
    params.set("src", src);
    params.set("t", String(stamp));
    return GALLERY + params.toString();
  }

  /**
   * The Chat picture a click landed on, or null. In Chat a picture is `img` inside its own `[role=button]`; that button
   * must hold exactly this one attachment image and no words other than a "+3" more-pictures label (the gallery shows
   * them all). Anything inside Chat's own viewer (`[role=dialog]`) is left alone.
   */
  function clickedImage(target) {
    if (!target || typeof target.closest !== "function") return null;
    if (target.closest('[role="dialog"]')) return null;
    const button = target.closest('[role="button"]');
    if (!button) return null;
    const images = button.querySelectorAll("img");
    if (images.length !== 1) return null;
    const words = (button.textContent ?? "").trim();
    if (words !== "" && !/^\+\s?\d{1,3}$/.test(words)) return null;
    const image = images[0];
    return originalUrl(image.currentSrc || image.src) ? image : null;
  }

  return Object.freeze({ originalUrl, viewerBounds, photoTarget, chatAccount, galleryUrl, clickedImage });
})();
