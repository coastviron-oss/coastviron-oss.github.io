// CK 구글챗 사진 창 (docs/chat-image-popup.md) — 구글챗 사진 주소와 보기 창 크기를 다루는 순수 함수.
// content.js보다 먼저 실리고, 시험(lib/chat-image-popup.test.ts)도 이 파일을 그대로 쓴다.
// 구글챗 화면의 사진은 `https://chat.google.com/api/get_attachment_url?url_type=FIFE_URL&content_type=image/png&...&sz=w512`
// 모양이다(2026-10-11 실제 화면에서 확인). `sz`가 크기다: w512는 너비 512, s330-c는 330 정사각형으로 자른 것, s0은 원본.
globalThis.ckChatImage = (() => {
  const HOST = "chat.google.com";
  const PATH = "/api/get_attachment_url";

  /** The original-size address of a Chat image attachment; null for anything else (profile photos, emoji, videos, files). */
  function originalUrl(src) {
    let url;
    try {
      url = new URL(src);
    } catch {
      return null;
    }
    if (url.protocol !== "https:" || url.hostname !== HOST || url.pathname !== PATH) return null;
    if (url.searchParams.get("url_type") !== "FIFE_URL") return null;
    if (!(url.searchParams.get("content_type") ?? "").startsWith("image/")) return null;
    url.searchParams.set("sz", "s0");
    return url.href;
  }

  /** Width ÷ height of the picture; null when Chat cropped the thumbnail (`-c`, `-p`) or it has not loaded. */
  function aspect(src, naturalWidth, naturalHeight) {
    let size;
    try {
      size = new URL(src).searchParams.get("sz") ?? "";
    } catch {
      return null;
    }
    const options = size.split("-").slice(1);
    if (options.includes("c") || options.includes("p")) return null;
    return naturalWidth > 0 && naturalHeight > 0 ? naturalWidth / naturalHeight : null;
  }

  /**
   * The viewer window: fitted to the picture within 90% of the screen, centred on the Chat window, kept on that screen.
   * `screen` is window.screen (availLeft/Top/Width/Height); `around` is the Chat window (screenX/Y, outerWidth/Height).
   */
  function viewerBounds(ratio, screen, around) {
    const FRAME_WIDTH = 16; // window borders
    const FRAME_HEIGHT = 72; // title bar + the popup's address line
    const maxWidth = Math.floor(screen.availWidth * 0.9);
    const maxHeight = Math.floor(screen.availHeight * 0.9);
    let width = maxWidth;
    let height = maxHeight;
    if (ratio) {
      const pictureHeight = Math.min(maxHeight - FRAME_HEIGHT, (maxWidth - FRAME_WIDTH) / ratio);
      width = Math.round(pictureHeight * ratio) + FRAME_WIDTH;
      height = Math.round(pictureHeight) + FRAME_HEIGHT;
    }
    width = Math.min(maxWidth, Math.max(width, 400));
    height = Math.min(maxHeight, Math.max(height, 300));
    const clamp = (value, low, high) => Math.min(Math.max(value, low), Math.max(low, high));
    const availLeft = screen.availLeft ?? 0;
    const availTop = screen.availTop ?? 0;
    return {
      left: clamp(Math.round(around.screenX + (around.outerWidth - width) / 2), availLeft, availLeft + screen.availWidth - width),
      top: clamp(Math.round(around.screenY + (around.outerHeight - height) / 2), availTop, availTop + screen.availHeight - height),
      width,
      height,
    };
  }

  /**
   * The Chat picture a click landed on, or null. In Chat a picture is `img` inside its own `[role=button]`; that button
   * must hold exactly this one attachment image and no words (a "+3 more" tile is left to Chat). Anything inside Chat's
   * own viewer (`[role=dialog]`) is left alone too.
   */
  function clickedImage(target) {
    if (!target || typeof target.closest !== "function") return null;
    if (target.closest('[role="dialog"]')) return null;
    const button = target.closest('[role="button"]');
    if (!button) return null;
    const images = button.querySelectorAll("img");
    if (images.length !== 1) return null;
    if ((button.textContent ?? "").trim() !== "") return null;
    const image = images[0];
    return originalUrl(image.currentSrc || image.src) ? image : null;
  }

  return Object.freeze({ originalUrl, aspect, viewerBounds, clickedImage });
})();
